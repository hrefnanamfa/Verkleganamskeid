#include "InvalidAnswerException.h"

InvalidAnswerException::InvalidAnswerException()
{
    //ctor
}

InvalidAnswerException::~InvalidAnswerException()
{
    //dtor
}
