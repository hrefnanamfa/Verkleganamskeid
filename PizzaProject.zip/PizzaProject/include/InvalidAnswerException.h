#ifndef INVALIDANSWEREXCEPTION_H
#define INVALIDANSWEREXCEPTION_H


class InvalidAnswerException
{
    public:
        InvalidAnswerException();
        virtual ~InvalidAnswerException();

    protected:

    private:
};

#endif // INVALIDANSWEREXCEPTION_H
