#ifndef MAINUI_H
#define MAINUI_H
#include <iostream>
#include "ManagingUI.h"
#include "SalesUI.h"
#include "BakeryUI.h"
#include "DeliveryUI.h"

using namespace std;

class MainUI
{
    private:

    public:
        MainUI();
        void startUI();

};

#endif // MAINUI_H
