#ifndef DELIVERYUI_H
#define DELIVERYUI_H


class DeliveryUI
{
    public:
        DeliveryUI();
        virtual ~DeliveryUI();
        void startUI();

    protected:

    private:
};

#endif // DELIVERYUI_H
