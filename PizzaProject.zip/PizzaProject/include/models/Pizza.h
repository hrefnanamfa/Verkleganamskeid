#ifndef PIZZA_H
#define PIZZA_H
#include <iostream>
#include "Topping.h"
#include "Base.h"
#include <vector>

using namespace std;

class Pizza
{
    private:
        int price;
        Base base;
        vector<Topping> toppings;

    public:
        Pizza();
        virtual ~Pizza();
        void setToppings(vector<Topping> toppings);
        int getPriceOfPizza();
        void addTopping(const Topping& topping);
        void setBase(const Base& base);
        void setPrice(int price);
        void write(ofstream& fout) const;
        void read(ifstream& fin);
        friend istream& operator >> (istream& in, Pizza& pizza);
        friend ostream& operator << (ostream& out, Pizza& pizza);

};


#endif // PIZZA_H
