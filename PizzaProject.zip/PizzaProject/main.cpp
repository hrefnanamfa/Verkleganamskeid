#include <iostream>
#include "include/ui/MainUI.h"
using namespace std;

int main()
{
    MainUI mainui;
    mainui.startUI();
    return 0;
}
